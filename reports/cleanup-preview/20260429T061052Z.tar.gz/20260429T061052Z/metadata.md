# Cleanup Preview Metadata

- Repository: `/data/APP/83_4dach_zimnoch/qt/4dach`
- Base ref: `HEAD`
- Timestamp UTC: `20260429T061052Z`
- Report dir: `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z`
- Worktree dir: `/tmp/4dach-cleanup-preview-20260429T061052Z-1565041`
- Ruff preview select: `F,I`
- Remove worktree on exit: `0`
- Run tests: `1`

## Current working tree status

```text
 M scripts/cleanup_preview.sh
?? reports/
```

## Current stash list

```text
stash@{Wed Apr 29 01:21:31 2026}: WIP on feat/freehand-fusion360-like: b9bb79d próba dodania kolejnego trybu czyli oldschool 4dach jak jeerzy pracowal czyli dodatkowy tryb w razie w jak nasz sie nie uda
```
