# Cleanup Preview Summary

- Report directory: `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z`
- Preview worktree: `/tmp/4dach-cleanup-preview-20260429T061052Z-1565041`
- Source archive: `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/source-20260429T061052Z.tar.gz`
- Patch diff: `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/cleanup-preview.diff`
- Diff stat: `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/cleanup-preview.diffstat`

## Command statuses

| Command | Exit code | Log |
| --- | ---: | --- |
| `uv-sync` | `0` | `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/uv-sync.txt` |
| `ruff-check-before` | `1` | `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/ruff-check-before.txt` |
| `ruff-format-diff-before` | `1` | `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/ruff-format-diff-before.txt` |
| `vulture-report` | `0` | `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/vulture-report.txt` |
| `deptry-report` | `0` | `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/deptry-report.txt` |
| `ruff-fix-preview` | `1` | `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/ruff-fix-preview.txt` |
| `ruff-format-preview` | `0` | `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/ruff-format-preview.txt` |
| `pytest-after-preview` | `139` | `/data/APP/83_4dach_zimnoch/qt/4dach/reports/cleanup-preview/20260429T061052Z/pytest-after-preview.txt` |

## Changed files in preview worktree

```text
 M .codex/hooks/branch_guard_common.py
 M .codex/hooks/stop_branch_guard.py
 M .codex/hooks/user_prompt_branch_snapshot.py
 M __main__.py
 M core/app_settings.py
 M core/canvas_mapper.py
 M core/geometry.py
 M core/layout_engine.py
 M core/models.py
 M core/project_state.py
 M core/reporting.py
 M dialogs.py
 M mainwindow.py
 M persistence.py
 M scripts/sync-review-backlog.py
 M tests/test_drawing_canvas.py
 M tests/test_geometry.py
 M tests/test_layout_engine.py
 M tests/test_mainwindow_ui_contract.py
 M tests/test_models_and_state.py
 M tests/test_reporting.py
 M ui/dialogs/__init__.py
 M ui/dialogs/company_dialog.py
 M ui/dialogs/material_dialog.py
 M ui/dialogs/settings_dialog.py
 M ui/dialogs/shape_dialogs.py
 M ui/drawing_canvas.py
 M ui/main_window.py
 M ui/report_view.py
 M ui/theme_manager.py
 M ui/toolbar.py
 M ui/workspace.py
```

## Diff stat

```text
 .codex/hooks/branch_guard_common.py         |   5 +-
 .codex/hooks/stop_branch_guard.py           |  35 +-
 .codex/hooks/user_prompt_branch_snapshot.py |   5 +-
 __main__.py                                 |   1 +
 core/app_settings.py                        |   1 +
 core/canvas_mapper.py                       |   4 +-
 core/geometry.py                            |  58 ++-
 core/layout_engine.py                       |  71 ++-
 core/models.py                              |  37 +-
 core/project_state.py                       | 137 ++++--
 core/reporting.py                           |  96 ++--
 dialogs.py                                  |  44 +-
 mainwindow.py                               |   1 +
 persistence.py                              |   1 +
 scripts/sync-review-backlog.py              |   8 +-
 tests/test_drawing_canvas.py                | 183 +++++--
 tests/test_geometry.py                      |  96 ++--
 tests/test_layout_engine.py                 |  99 +++-
 tests/test_mainwindow_ui_contract.py        | 240 ++++++---
 tests/test_models_and_state.py              |  99 +++-
 tests/test_reporting.py                     |  55 ++-
 ui/dialogs/__init__.py                      |   1 +
 ui/dialogs/company_dialog.py                |   1 +
 ui/dialogs/material_dialog.py               |  23 +-
 ui/dialogs/settings_dialog.py               |  44 +-
 ui/dialogs/shape_dialogs.py                 |   1 +
 ui/drawing_canvas.py                        | 733 +++++++++++++++++++++-------
 ui/main_window.py                           | 293 ++++++++---
 ui/report_view.py                           |  13 +-
 ui/theme_manager.py                         |  42 +-
 ui/toolbar.py                               |  53 +-
 ui/workspace.py                             |  10 +-
 32 files changed, 1839 insertions(+), 651 deletions(-)
```
